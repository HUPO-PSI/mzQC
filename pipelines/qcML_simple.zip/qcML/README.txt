Description:
This is a simple QC workflow,
producing a qcML file from a mzML
file (picked peaks) giving an overview over:
MS aquisition result details,
recorded spectra, total ion current,
theoretical vs. experimental fractional masses,
MS identification result details,
identified peptides and proteins,
mass accuracy, recorded vs. identified spectra
and the number of features.

Import & run workflow:
extract this zip file to /tmp (will create folder qcML)
import /tmp/qcML/simple QC workflow.zip in KNIME
run workflow which creates (or updates) /tmp/test.qcML
